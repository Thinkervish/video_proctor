import numpy as np
import mediapipe as mp
import cv2

class AttentionAgent:
    def __init__(self):
        mp_mesh = mp.solutions.face_mesh
        self.face_mesh = mp_mesh.FaceMesh(refine_landmarks=True)
        
        self.left_eye = [33, 160, 158, 133, 153, 144]
        self.right_eye = [362, 385, 387, 263, 373, 380]
        self.left_iris = 468
        self.right_iris = 473
        
        self.baseline_ear = 0
        self.calib_frames = 0
        self.calib_time = 60
        
        self.head_yaw_limit = 160
        self.head_pitch_limit = 220

    def _get_ear(self, lm, eye, w, h):
        pts = [(int(lm[i].x * w), int(lm[i].y * h)) for i in eye]
        v1 = np.linalg.norm(np.array(pts[1]) - np.array(pts[5]))
        v2 = np.linalg.norm(np.array(pts[2]) - np.array(pts[4]))
        h_dist = np.linalg.norm(np.array(pts[0]) - np.array(pts[3]))
        return (v1 + v2) / (2.0 * h_dist + 1e-6)

    def _get_gaze(self, lm):
        avg_x = (lm[self.left_iris].x + lm[self.right_iris].x)/2
        if avg_x < 0.3: return "LEFT_EXTREME"
        if avg_x < 0.45: return "LEFT_SOFT"
        if avg_x > 0.7: return "RIGHT_EXTREME"
        if avg_x > 0.55: return "RIGHT_SOFT"
        return "CENTER"

    def _head_pose(self, lm, w, h):
        ids = [1, 33, 263, 152, 10]
        pts = [(int(lm[i].x*w), int(lm[i].y*h)) for i in ids]
        nose, l, r, chin, head = pts
        yaw = r[0] - l[0]
        pitch = chin[1] - head[1]
        return yaw, pitch, nose

    def analyze_attention(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mesh = self.face_mesh.process(rgb)

        if not mesh.multi_face_landmarks:
            return {"attention": 0, "drowsy": False, "gaze": "UNKNOWN", "head_turn": False}

        lm = mesh.multi_face_landmarks[0].landmark
        h, w, _ = frame.shape

        yaw, pitch, nose = self._head_pose(lm, w, h)
        gaze = self._get_gaze(lm)
        ear = (self._get_ear(lm, self.left_eye, w, h) + self._get_ear(lm, self.right_eye, w, h)) / 2

        if self.calib_frames < self.calib_time:
            self.baseline_ear += ear
            self.calib_frames += 1
            return {"attention": 100, "drowsy": False, "gaze": gaze, "head_turn": False}

        if self.calib_frames == self.calib_time:
            self.baseline_ear /= self.calib_time
            self.calib_frames += 1

        score = 100
        
        # Drowsiness penalty
        if ear < self.baseline_ear * 0.6:
            score -= 40

        # Gaze penalty
        if gaze in ["LEFT_EXTREME", "RIGHT_EXTREME"]:
            score -= 30
        elif gaze in ["LEFT_SOFT", "RIGHT_SOFT"]:
            score -= 5

        # Head turn penalty
        head_turn = False
        if abs(yaw) > self.head_yaw_limit:
            score -= 15
            head_turn = True
        if abs(pitch) > self.head_pitch_limit:
            score -= 15
            head_turn = True

        # Render gaze/pose indicators on frame
        cv2.circle(frame, nose, 3, (0, 255, 255), -1)
        if gaze != "CENTER":
            cv2.putText(frame, f"Gaze: {gaze}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,165,255), 2)

        return {
            "attention": max(score, 0), 
            "drowsy": score < 50,
            "gaze": gaze,
            "head_turn": head_turn
        }