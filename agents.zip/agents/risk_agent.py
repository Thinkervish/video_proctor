import time
class RiskAgent:
    def __init__(self):
        self.suspicion_score = 0
        self.timeline = []

        self.weights = {
            "illegal_object": 25,
            "multiple_people": 30,
            "low_attention": 15,
            "drowsy": 10,
            "face_not_visible": 20,
            "head_turned": 15,
            "talking": 25,
            "loud_noise": 15,
            "tab_switched": 40
        }

        self.last_risk_time = {}
        self.risk_cooldown = 5  # seconds

    def update_risk(self, event):
        now = time.time()

        # prevent rapid stacking
        if event in self.last_risk_time:
            if now - self.last_risk_time[event] < self.risk_cooldown:
                return

        self.last_risk_time[event] = now

        if event in self.weights:
            self.suspicion_score = min(100, self.suspicion_score + self.weights[event])
            self.timeline.append({
                "event": event,
                "score": self.suspicion_score,
                "time": time.strftime("%H:%M:%S")
            })

    def get_risk_level(self):
        score = self.suspicion_score
        if score < 30:
            return "LOW"
        elif score < 70:
            return "MEDIUM"
        else:
            return "HIGH"