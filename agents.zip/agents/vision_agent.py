import time
from ultralytics import YOLO
import mediapipe as mp
import cv2

class VisionAgent:
    def __init__(self, model_path="models/yolov8s.pt"):
        self.illegal_objects = ["cell phone", "book", "laptop"]
        
        # Upgraded to YOLOv8 Small model for better precision
        self.model = YOLO(model_path)
        
        mp_face = mp.solutions.face_detection
        self.face_detector = mp_face.FaceDetection(min_detection_confidence=0.5)
        
        self.multi_person_start = None
        self.multi_person_threshold = 2

    def analyze_vision(self, frame):
        results = self.model(frame, verbose=False)

        people = 0
        illegal = []

        # Parse YOLOv8s bounding boxes
        for r in results:
            for box in r.boxes:
                cls = int(box.cls)
                label = self.model.names[cls]
                conf = float(box.conf)

                x1, y1, x2, y2 = map(int, box.xyxy[0])
                area = (x2 - x1) * (y2 - y1)
                
                if area < 5000:
                    continue

                if label == "person" and conf > 0.6:
                    people += 1

                if label in self.illegal_objects and conf > 0.45:
                    illegal.append(label)

        # Multi-person logic
        multi_flag = False
        if people > 1:
            if self.multi_person_start is None:
                self.multi_person_start = time.time()
            elif time.time() - self.multi_person_start > self.multi_person_threshold:
                multi_flag = True
                self.multi_person_start = None
        else:
            self.multi_person_start = None

        # Face Visibility and Rendering 
        face_results = self.face_detector.process(frame)
        face_visible = bool(face_results.detections)

        if face_visible:
            h, w, _ = frame.shape
            for detection in face_results.detections:
                bboxC = detection.location_data.relative_bounding_box
                x = int(bboxC.xmin * w)
                y = int(bboxC.ymin * h)
                fw = int(bboxC.width * w)
                fh = int(bboxC.height * h)
                
                # Render an elegant oval matching the dimensions of the face rather than a generic box.
                center = (x + fw // 2, y + fh // 2)
                axes = (fw // 2, fh // 2)
                
                # Green hollow ellipse, rotated 0 degrees
                cv2.ellipse(frame, center, axes, 0, 0, 360, (0, 255, 0), 2)

        return {
            "illegal_objects": illegal,
            "multiple_people": multi_flag,
            "face_visible": face_visible
        }